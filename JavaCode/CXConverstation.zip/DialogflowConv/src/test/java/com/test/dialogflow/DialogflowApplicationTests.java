package com.test.dialogflow;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DialogflowApplicationTests {

	@Test
	void contextLoads() {
	}

}
