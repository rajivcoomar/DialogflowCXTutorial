package com.test.dialogflow;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DialogflowApplication {

	public static void main(String[] args) {
		SpringApplication.run(DialogflowApplication.class, args);
	}

}
