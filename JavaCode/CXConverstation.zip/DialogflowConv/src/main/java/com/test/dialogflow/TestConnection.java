package com.test.dialogflow;

import java.io.IOException;
import java.util.ArrayList;

import com.google.api.gax.rpc.ApiException;
import com.google.cloud.dialogflow.v2beta1.Conversation;
import com.google.cloud.dialogflow.v2beta1.ConversationsClient;
import com.google.cloud.dialogflow.v2beta1.ListConversationsRequest;
import com.google.cloud.dialogflow.v2beta1.ListMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.LocationName;
import com.google.cloud.dialogflow.v2beta1.Message;
import com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListMessagesPagedResponse;

public class TestConnection {

    public static void main(String[] args) {

        String projectId = "<project_id>";
        String locationId = "<locationId>";

        double startTime, endTime;

        String convId = "";
        try {
            startTime = System.nanoTime() / 1e9; // Record start time in seconds

            ConversationsClient conversationsClient = ConversationsClient.create();

            endTime = System.nanoTime() / 1e9; // Record end time in seconds
            System.out.println("Creating ConversationsClient took: " + (endTime - startTime) + " seconds");

            LocationName parent = LocationName.of(projectId, locationId);
            startTime = System.nanoTime() / 1e9; // Record start time in seconds
        	ListConversationsRequest request = ListConversationsRequest.newBuilder()
			           .setParent(parent.toString())
			           .setPageSize(2)
			           .setFilter("lifecycle_state = \"COMPLETED\"") //IN_PROGRESS , COMPLETED
			           .build();
        	for (Conversation element : conversationsClient.listConversations(request).iterateAll()) {
                System.out.println("name");
                System.out.println(element.getName());
                convId = element.getName();
                convId = convId.substring(convId.lastIndexOf("/") + 1);
                break;
            }
            endTime = System.nanoTime() / 1e9; // Record end time in seconds
            System.out.println("Fetching Conversation list took: " + (endTime - startTime) + " seconds");

            System.out.println("convId");
            System.out.println(convId);

            ArrayList<String> convValue = new ArrayList<>();

            ListMessagesRequest req = ListMessagesRequest.newBuilder().setParent("projects/" + projectId + "/conversations/" + convId).build();
            startTime = System.nanoTime() / 1e9; // Record start time in seconds
            ListMessagesPagedResponse response = conversationsClient.listMessages(req);
            for (Message element : response.getPage().getResponse().getMessagesList()) {
                if (!element.getContent().isEmpty())
                    convValue.add(element.getParticipantRole().toString() + " : " + element.getContent());
            }
            endTime = System.nanoTime() / 1e9; // Record end time in seconds
            System.out.println("Fetching Messages took: " + (endTime - startTime) + " seconds");

            startTime = System.nanoTime() / 1e9; // Record start time in seconds
            for (int i = convValue.size() - 1; i > 0; i--) {
                System.out.println(convValue.get(i));
            }
            endTime = System.nanoTime() / 1e9; // Record end time in seconds
            System.out.println("Printing Messages took: " + (endTime - startTime) + " seconds");

            conversationsClient.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }
}
