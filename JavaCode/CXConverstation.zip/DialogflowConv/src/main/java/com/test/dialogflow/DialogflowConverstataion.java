package com.test.dialogflow;


import java.io.IOException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.google.cloud.dialogflow.v2beta1.Conversation;
import com.google.cloud.dialogflow.v2beta1.ConversationName;
import com.google.cloud.dialogflow.v2beta1.ConversationsClient;
import com.google.cloud.dialogflow.v2beta1.ConversationsClient.ListMessagesPagedResponse;
import com.google.cloud.dialogflow.v2beta1.ListConversationsRequest;
import com.google.cloud.dialogflow.v2beta1.ListMessagesRequest;
import com.google.cloud.dialogflow.v2beta1.LocationName;
import com.google.cloud.dialogflow.v2beta1.Message;

@RestController
public class DialogflowConverstataion {
	

	@RequestMapping("/getLastConversation")
	public String hello() throws IOException {
		String projectId = "<project_id>";
		String locationId = "<locationId>";
		String convId = "";
		String time = "";
		String htmlMsg = "";

		try{
			LocationName parent = LocationName.of(projectId, locationId);
			
			ConversationsClient conversationsClient = ConversationsClient.create();
			
			ListConversationsRequest request = ListConversationsRequest.newBuilder()
									           .setParent(parent.toString())
									           .setPageSize(2)
									           .setFilter("lifecycle_state = \"IN_PROGRESS\"") //IN_PROGRESS , COMPLETED
									           .build();
			for (Conversation element : conversationsClient.listConversations(request).iterateAll()) {
				convId = element.getName();
				convId = convId.substring(convId.lastIndexOf("/")+1);
				Timestamp ts=new Timestamp(element.getStartTime().getSeconds()*1000);  
				Date date = ts;
				java.text.DateFormat dd =new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
				dd.setTimeZone( java.util.TimeZone.getTimeZone( "Europe/London") );
				time =  dd.format(date);
				break;
			}

			htmlMsg = "<!DOCTYPE html><html><head><meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"><style>body {  margin: 0 auto; max-width: 500px;  padding: 0 10px;}.container {  border: 2px solid #dedede;  background-color: #f1f1f1;  border-radius: 5px;  padding: 5px;  margin: 5px 0;}.darker {  border-color: #ccc;  background-color: #ddd;}.container::after {  content: \"\";  clear: both; display: table;}.container img {  float: left;  max-width: 25px;  width: 100%;  margin-right: 10px;  border-radius: 50%;}.container img.right {float: right;  margin-left: 10px;  margin-right:0;}.time-right {  float: right;  color: #aaa;}.time-left {  float: left;  color: #999;}</style></head><body><h2>CCAI Messages </h2><h3> Call ID : "+convId+"<br><br> Time of Call : "+time+"</h3>";
			ArrayList<String> convValue = new ArrayList<>();

			ListMessagesRequest req = ListMessagesRequest.newBuilder().setParent("projects/"+projectId+"/conversations/"+convId).build();
			ListMessagesPagedResponse response = conversationsClient.listMessages(req);
			for (Message element : response.getPage().getResponse().getMessagesList()) {
				if(!element.getContent().isEmpty())
				{
					if(element.getParticipantRole().toString().equalsIgnoreCase("AUTOMATED_AGENT"))
					{
						String tmptime="";
						Timestamp ts1=new Timestamp(element.getSendTime().getSeconds()*1000);  
						Date date1 = ts1;
						java.text.DateFormat dd1 =new SimpleDateFormat("HH:mm:ss");
						dd1.setTimeZone( java.util.TimeZone.getTimeZone("Europe/London") );
						tmptime =  dd1.format(date1);
						String tmpbot = "<div class=\"container\">  <img  src =\"https://miro.medium.com/max/512/1*STUHV-PX-h2OJk_Ic1Ne9Q.png\"alt=\"Bot\" style=\"width:100%;\">  <p>"+element.getContent()+"</p>  <span class=\"time-right\">"+tmptime+"</span></div>";
						convValue.add(tmpbot);
					}
					else
					{
						String tmptime="";
						Timestamp ts1=new Timestamp(element.getSendTime().getSeconds()*1000);  
						Date date1 = ts1;
						java.text.DateFormat dd1 =new SimpleDateFormat("HH:mm:ss");
						dd1.setTimeZone( java.util.TimeZone.getTimeZone( "Europe/London" ) );
						tmptime =  dd1.format(date1);
						String tmpuser = "<div class=\"container darker\">  <img src=\"https://cdn-icons-png.flaticon.com/512/2922/2922506.png\" alt=\"User\" class=\"right\" style=\"width:100%;\">  <p class=\"right\">"+element.getContent()+"</p>  <span class=\"time-left\">"+tmptime+"</span></div>";
						convValue.add(tmpuser);
					}
				}
			}

			for(int i=convValue.size()-1;i>= 0;i--)
			{
				htmlMsg = htmlMsg + convValue.get(i);
			}

			htmlMsg = htmlMsg + "</body></html>";
			conversationsClient.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}

		return htmlMsg;
	}



}